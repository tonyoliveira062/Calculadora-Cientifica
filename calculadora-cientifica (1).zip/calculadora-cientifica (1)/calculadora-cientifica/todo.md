# Project TODO

- [x] Interface da calculadora com display e botões
- [x] Operações básicas (soma, subtração, multiplicação, divisão)
- [x] Funções científicas (seno, cosseno, tangente, logaritmo, exponencial)
- [x] Suporte a potências e raízes
- [x] Suporte a parênteses e precedência de operadores
- [x] Tratamento de erros de sintaxe
- [x] Tratamento de erros de expressão matemática
- [x] Mensagens de erro amigáveis ao usuário
- [x] Histórico de cálculos
- [x] Botão de limpar (C) e limpar entrada (CE)
- [x] Suporte a entrada via teclado (números, operadores, Enter, Backspace, Escape)
- [x] Compatibilidade com Windows (scripts batch e guia)
