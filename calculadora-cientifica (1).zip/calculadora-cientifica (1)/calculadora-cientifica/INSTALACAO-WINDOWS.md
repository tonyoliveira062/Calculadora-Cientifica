# Guia de Instalação - Windows

## Pré-requisitos

Antes de começar, certifique-se de ter instalado:

### 1. Node.js (obrigatório)

O Node.js inclui o npm, que é necessário para instalar o pnpm.

**Download**: https://nodejs.org/

- Recomendado: Versão LTS (Long Term Support)
- Clique em "Download" e execute o instalador
- Siga as instruções padrão de instalação

**Verificar instalação**:
```bash
node --version
npm --version
```

### 2. Git (opcional, mas recomendado)

Útil para controle de versão e atualizações.

**Download**: https://git-scm.com/download/win

- Execute o instalador
- Siga as instruções padrão

## Instalação Rápida (Recomendado)

### Opção 1: Usando o Script Automático

1. **Extraia o arquivo ZIP** em um local de sua escolha
   - Clique com botão direito em `calculadora-cientifica.zip`
   - Selecione "Extrair tudo..."
   - Escolha a pasta de destino

2. **Abra a pasta do projeto** no Windows Explorer

3. **Clique duas vezes** em `install-windows.bat`
   - Uma janela de terminal abrirá
   - Aguarde a conclusão da instalação
   - Pressione qualquer tecla quando solicitado

4. **Inicie o servidor** clicando duas vezes em `iniciar-desenvolvimento.bat`
   - A aplicação abrirá automaticamente em `http://localhost:5173`

### Opção 2: Instalação Manual via Terminal

1. **Abra o PowerShell ou Prompt de Comando**
   - Pressione `Windows + R`
   - Digite `cmd` e pressione Enter

2. **Navegue até a pasta do projeto**
   ```bash
   cd C:\caminho\para\calculadora-cientifica
   ```

3. **Instale as dependências**
   ```bash
   pnpm install
   ```
   
   Se o pnpm não estiver instalado, execute primeiro:
   ```bash
   npm install -g pnpm
   ```

4. **Inicie o servidor de desenvolvimento**
   ```bash
   pnpm dev
   ```

5. **Abra no navegador**
   - A URL será exibida no terminal (geralmente `http://localhost:5173`)
   - Copie e cole no seu navegador

## Usando no VSCode

1. **Abra o VSCode**

2. **Abra a pasta do projeto**
   - File → Open Folder
   - Selecione a pasta `calculadora-cientifica`

3. **Abra o terminal integrado**
   - Pressione `Ctrl + ` (backtick)
   - Ou vá em Terminal → New Terminal

4. **Instale as dependências**
   ```bash
   pnpm install
   ```

5. **Inicie o servidor**
   ```bash
   pnpm dev
   ```

6. **Acesse a aplicação**
   - Clique no link exibido no terminal
   - Ou abra `http://localhost:5173` no navegador

## Comandos Úteis

| Comando | Descrição |
|---------|-----------|
| `pnpm install` | Instala todas as dependências |
| `pnpm dev` | Inicia o servidor de desenvolvimento |
| `pnpm build` | Compila o projeto para produção |
| `pnpm preview` | Visualiza a compilação de produção |

## Solução de Problemas

### Erro: "pnpm: comando não encontrado"

**Solução**: Instale o pnpm globalmente
```bash
npm install -g pnpm
```

### Erro: "node: comando não encontrado"

**Solução**: Instale o Node.js em https://nodejs.org/

### Porta 5173 já está em uso

**Solução**: Use uma porta diferente
```bash
pnpm dev -- --port 5174
```

### Dependências não instaladas corretamente

**Solução**: Limpe o cache e reinstale
```bash
pnpm store prune
pnpm install
```

### Erro ao executar os scripts .bat

**Solução**: Execute o PowerShell como Administrador
- Clique com botão direito em PowerShell
- Selecione "Executar como administrador"
- Navegue até a pasta e execute o script novamente

## Estrutura do Projeto

```
calculadora-cientifica/
├── client/                    # Frontend (React)
│   ├── src/
│   │   ├── components/       # Componentes React
│   │   ├── pages/            # Páginas da aplicação
│   │   ├── App.tsx           # Componente principal
│   │   └── main.tsx          # Ponto de entrada
│   └── public/               # Arquivos estáticos
├── package.json              # Dependências do projeto
├── vite.config.ts            # Configuração do Vite
├── install-windows.bat       # Script de instalação
├── iniciar-desenvolvimento.bat # Script para iniciar
├── userGuide.md              # Guia do usuário
├── INSTALACAO-WINDOWS.md     # Este arquivo
└── todo.md                   # Lista de funcionalidades
```

## Próximos Passos

1. **Familiarize-se com a calculadora**
   - Leia o arquivo `userGuide.md`

2. **Explore o código**
   - Arquivo principal: `client/src/components/Calculator.tsx`
   - Página inicial: `client/src/pages/Home.tsx`

3. **Customize conforme necessário**
   - Altere cores em `client/src/index.css`
   - Modifique o layout em `client/src/components/Calculator.tsx`
   - Adicione novas funcionalidades

4. **Compile para produção**
   ```bash
   pnpm build
   ```

## Suporte Adicional

Se encontrar problemas:

1. Verifique se o Node.js está instalado corretamente
2. Tente limpar o cache: `pnpm store prune`
3. Reinstale as dependências: `pnpm install`
4. Reinicie o VSCode e o terminal

## Compatibilidade

✅ Windows 10 e superior
✅ Windows 11
✅ PowerShell
✅ Prompt de Comando (cmd)
✅ Git Bash
✅ Windows Terminal

Divirta-se com sua calculadora científica! 🚀
