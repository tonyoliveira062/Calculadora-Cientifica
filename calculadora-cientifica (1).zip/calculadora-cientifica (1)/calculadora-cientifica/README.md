# Calculadora Científica

Uma calculadora científica moderna e completa com suporte a operações básicas, funções trigonométricas, logaritmos, potências, raízes e entrada via teclado.

## 🚀 Quick Start

### Windows

1. **Clique duas vezes** em `install-windows.bat` para instalar as dependências
2. **Clique duas vezes** em `iniciar-desenvolvimento.bat` para iniciar o servidor
3. A aplicação abrirá em `http://localhost:5173`

Para instruções detalhadas, veja [INSTALACAO-WINDOWS.md](INSTALACAO-WINDOWS.md)

### macOS / Linux

```bash
pnpm install
pnpm dev
```

## 📋 Funcionalidades

✅ **Operações Básicas**: Soma, subtração, multiplicação, divisão
✅ **Funções Científicas**: sin, cos, tan, log, ln, sqrt, asin, acos, atan
✅ **Potências e Raízes**: Suporte a x^y e √x
✅ **Constantes Matemáticas**: π (pi) e e
✅ **Parênteses**: Controle completo de precedência
✅ **Entrada via Teclado**: Números, operadores, Enter, Backspace, Escape
✅ **Histórico de Cálculos**: Rastreamento de todas as operações
✅ **Tratamento de Erros**: Mensagens claras para erros de sintaxe
✅ **Interface Moderna**: Design responsivo e intuitivo

## ⌨️ Atalhos de Teclado

| Tecla | Ação |
|-------|------|
| `0-9` | Digitar números |
| `+`, `-`, `*`, `/` | Operadores |
| `.` | Decimal |
| `(`, `)` | Parênteses |
| `Enter` ou `=` | Calcular |
| `Backspace` | Apagar último caractere (CE) |
| `Escape` | Limpar tudo (C) |

## 📁 Estrutura do Projeto

```
calculadora-cientifica/
├── client/                    # Frontend (React + TypeScript)
│   ├── src/
│   │   ├── components/       # Componentes React
│   │   │   └── Calculator.tsx # Componente principal
│   │   ├── pages/            # Páginas
│   │   ├── App.tsx           # Componente raiz
│   │   └── main.tsx          # Ponto de entrada
│   └── public/               # Arquivos estáticos
├── package.json              # Dependências
├── vite.config.ts            # Configuração Vite
├── install-windows.bat       # Script de instalação (Windows)
├── iniciar-desenvolvimento.bat # Script de inicialização (Windows)
├── userGuide.md              # Guia do usuário
├── INSTALACAO-WINDOWS.md     # Guia de instalação Windows
└── README.md                 # Este arquivo
```

## 🛠️ Tecnologias

- **React 19** - Framework UI
- **TypeScript** - Tipagem estática
- **Tailwind CSS 4** - Estilização
- **shadcn/ui** - Componentes de UI
- **mathjs** - Avaliação de expressões matemáticas
- **Vite** - Build tool
- **pnpm** - Gerenciador de pacotes

## 📖 Documentação

- **[userGuide.md](userGuide.md)** - Guia completo do usuário
- **[INSTALACAO-WINDOWS.md](INSTALACAO-WINDOWS.md)** - Instruções detalhadas para Windows
- **[todo.md](todo.md)** - Lista de funcionalidades implementadas

## 💻 Desenvolvimento

### Instalar dependências
```bash
pnpm install
```

### Iniciar servidor de desenvolvimento
```bash
pnpm dev
```

### Compilar para produção
```bash
pnpm build
```

### Visualizar compilação de produção
```bash
pnpm preview
```

## 🎨 Personalização

### Alterar cores e estilos
- Edite `client/src/index.css` para mudar o tema
- Modifique `client/src/components/Calculator.tsx` para alterar o layout

### Adicionar novas funções
- Edite o componente `Calculator.tsx`
- A biblioteca `mathjs` suporta muitas funções matemáticas

### Mudar título e logo
- Edite `client/src/const.ts`
- Substitua as imagens em `client/public/`

## 🐛 Solução de Problemas

### Erro: "pnpm: comando não encontrado"
```bash
npm install -g pnpm
```

### Porta 5173 já está em uso
```bash
pnpm dev -- --port 5174
```

### Limpar cache e reinstalar
```bash
pnpm store prune
pnpm install
```

## 📝 Licença

Este projeto é fornecido como está, livre para uso pessoal e comercial.

## 🤝 Suporte

Para dúvidas ou sugestões, consulte a documentação ou modifique o código conforme necessário.

---

**Desenvolvido com ❤️ usando Manus**

Divirta-se calculando! 🧮
