# Guia do Usuário - Calculadora Científica

## Informações do Website

**Objetivo**: Esta calculadora científica permite realizar desde operações matemáticas básicas até cálculos científicos complexos com funções trigonométricas, logaritmos, potências e raízes.

**Acesso**: Público, não requer login.

## Desenvolvido com Manus

Esta aplicação foi construída com tecnologias modernas e robustas. O **frontend** utiliza React 19 com TypeScript para garantir uma interface responsiva e tipagem segura, Tailwind CSS 4 para estilização moderna, e shadcn/ui para componentes de interface elegantes. A biblioteca **mathjs** é responsável pela avaliação precisa de expressões matemáticas complexas. O **deployment** conta com infraestrutura de auto-scaling e CDN global para acesso rápido de qualquer lugar do mundo.

## Usando Sua Calculadora

A calculadora oferece uma interface completa com display digital e botões organizados por categoria. Para realizar **operações básicas**, clique nos números desejados e depois no operador ("+", "-", "×", "÷"). Clique em "=" para ver o resultado. Por exemplo, para calcular 5 + 3, clique em "5" → "+" → "3" → "=" e veja o resultado 8.

Para usar **funções científicas**, clique primeiro no botão da função desejada (sin, cos, tan, log, ln, √) e depois insira o valor. A calculadora adiciona automaticamente o parêntese de abertura. Digite o número e feche com ")". Por exemplo, para calcular sin(9), clique em "sin" → "9" → ")" → "=".

Você pode criar **expressões complexas** combinando números, operadores e funções. Use os botões "(" e ")" para controlar a ordem das operações. A calculadora respeita a precedência matemática correta. Para potências, use o botão "x^y" entre a base e o expoente. As constantes matemáticas π e e estão disponíveis através de botões dedicados.

O **histórico de cálculos** aparece automaticamente abaixo da calculadora após cada operação bem-sucedida. Ele mostra a expressão completa e seu resultado, com os cálculos mais recentes no topo. Use o botão "C" para limpar completamente o display e começar um novo cálculo, ou "CE" para apagar apenas o último caractere digitado.

Quando ocorre um **erro de sintaxe ou expressão**, o display mostra "Erro" e uma mensagem explicativa aparece na tela. Erros comuns incluem parênteses não balanceados, operadores consecutivos sem números entre eles, ou funções sem argumentos. Após um erro, clique em "C" para limpar e começar novamente.

### Atalhos de Teclado

Você pode usar o teclado do computador para uma experiência mais rápida. Digite **números** (0-9) normalmente. Para **operadores**, use "+" para adição, "-" para subtração, "*" para multiplicação e "/" para divisão. Pressione **Enter** ou "=" para calcular, **Backspace** para apagar o último caractere (CE), e **Escape** para limpar tudo (C). Você também pode digitar "." para decimais e "(" ou ")" para parênteses.

## Gerenciando Sua Calculadora

Acesse o painel de gerenciamento através do ícone no canto superior direito da interface. No painel **Settings**, você pode personalizar o título e logotipo da aplicação através das variáveis VITE_APP_TITLE e VITE_APP_LOGO. O painel **Code** permite visualizar e baixar todos os arquivos do projeto para personalização avançada.

## Próximos Passos

Converse com Manus AI a qualquer momento para solicitar mudanças ou adicionar funcionalidades. Experimente realizar cálculos complexos combinando múltiplas funções e operadores para explorar todo o potencial da calculadora científica.
