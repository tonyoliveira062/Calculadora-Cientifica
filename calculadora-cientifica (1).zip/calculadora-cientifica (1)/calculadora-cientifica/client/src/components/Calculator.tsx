import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { evaluate } from "mathjs";
import { toast } from "sonner";

export default function Calculator() {
  const [display, setDisplay] = useState("0");
  const [expression, setExpression] = useState("");
  const [history, setHistory] = useState<string[]>([]);

  // Suporte a entrada via teclado
  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      const key = event.key;

      // Números (0-9)
      if (/^[0-9]$/.test(key)) {
        event.preventDefault();
        handleNumber(key);
      }
      // Operadores
      else if (key === "+") {
        event.preventDefault();
        handleOperator("+");
      } else if (key === "-") {
        event.preventDefault();
        handleOperator("-");
      } else if (key === "*") {
        event.preventDefault();
        handleOperator("*");
      } else if (key === "/") {
        event.preventDefault();
        handleOperator("/");
      }
      // Decimal
      else if (key === ".") {
        event.preventDefault();
        handleDecimal();
      }
      // Parênteses
      else if (key === "(") {
        event.preventDefault();
        handleParenthesis("(");
      } else if (key === ")") {
        event.preventDefault();
        handleParenthesis(")");
      }
      // Igual
      else if (key === "Enter" || key === "=") {
        event.preventDefault();
        handleEquals();
      }
      // Backspace para CE
      else if (key === "Backspace") {
        event.preventDefault();
        handleClearEntry();
      }
      // Escape para C
      else if (key === "Escape") {
        event.preventDefault();
        handleClear();
      }
    };

    window.addEventListener("keydown", handleKeyPress);
    return () => window.removeEventListener("keydown", handleKeyPress);
  }, [display, expression]);

  const handleNumber = (num: string) => {
    if (display === "0" || display === "Erro") {
      setDisplay(num);
      setExpression(num);
    } else {
      setDisplay(display + num);
      setExpression(expression + num);
    }
  };

  const handleOperator = (op: string) => {
    if (display === "Erro") return;
    setDisplay(display + " " + op + " ");
    setExpression(expression + op);
  };

  const handleFunction = (func: string) => {
    if (display === "Erro") return;
    setDisplay(display + func + "(");
    setExpression(expression + func + "(");
  };

  const handleClear = () => {
    setDisplay("0");
    setExpression("");
  };

  const handleClearEntry = () => {
    if (display.length > 1) {
      setDisplay(display.slice(0, -1));
      setExpression(expression.slice(0, -1));
    } else {
      setDisplay("0");
      setExpression("");
    }
  };

  const handleEquals = () => {
    // Evitar múltiplas chamadas
    if (display === "Erro") return;
    try {
      if (!expression || expression.trim() === "") {
        toast.error("Nenhuma expressão para calcular");
        return;
      }

      // Validar parênteses balanceados
      const openParens = (expression.match(/\(/g) || []).length;
      const closeParens = (expression.match(/\)/g) || []).length;
      if (openParens !== closeParens) {
        throw new Error("Parênteses não balanceados");
      }

      const result = evaluate(expression);
      const resultStr = String(result);
      
      setHistory([...history, `${display} = ${resultStr}`]);
      setDisplay(resultStr);
      setExpression(resultStr);
      toast.success("Cálculo realizado com sucesso!");
    } catch (error) {
      if (error instanceof Error) {
        if (error.message.includes("Unexpected")) {
          toast.error("Erro de sintaxe: Verifique a expressão digitada");
        } else if (error.message.includes("Undefined")) {
          toast.error("Erro: Função ou variável não definida");
        } else if (error.message.includes("parenthesis")) {
          toast.error("Erro de sintaxe: Parênteses não balanceados");
        } else {
          toast.error(`Erro na expressão: ${error.message}`);
        }
      } else {
        toast.error("Erro desconhecido ao calcular");
      }
      setDisplay("Erro");
    }
  };

  const handleDecimal = () => {
    if (display === "Erro") return;
    if (!display.includes(".")) {
      setDisplay(display + ".");
      setExpression(expression + ".");
    }
  };

  const handleParenthesis = (paren: string) => {
    if (display === "Erro") return;
    setDisplay(display + paren);
    setExpression(expression + paren);
  };

  const handleConstant = (constant: string, value: string) => {
    if (display === "Erro") {
      setDisplay(value);
      setExpression(value);
    } else if (display === "0") {
      setDisplay(value);
      setExpression(value);
    } else {
      setDisplay(display + value);
      setExpression(expression + value);
    }
  };

  const buttonClass = "h-14 text-lg font-semibold";
  const operatorClass = "h-14 text-lg font-semibold bg-orange-500 hover:bg-orange-600 text-white";
  const functionClass = "h-14 text-sm font-semibold bg-blue-500 hover:bg-blue-600 text-white";

  return (
    <div className="w-full max-w-2xl mx-auto space-y-4">
      <Card className="p-6 bg-gradient-to-br from-slate-900 to-slate-800 text-white">
        <div className="space-y-4">
          {/* Display */}
          <div className="bg-slate-950 rounded-lg p-4 min-h-20 flex items-end justify-end">
            <div className="text-right w-full">
              <div className="text-4xl font-bold break-all">{display}</div>
              <div className="text-xs text-slate-500 mt-2">💡 Use o teclado para digitar números e operadores</div>
            </div>
          </div>

          {/* Scientific Functions Row 1 */}
          <div className="grid grid-cols-5 gap-2">
            <Button onClick={() => handleFunction("sin")} className={functionClass}>
              sin
            </Button>
            <Button onClick={() => handleFunction("cos")} className={functionClass}>
              cos
            </Button>
            <Button onClick={() => handleFunction("tan")} className={functionClass}>
              tan
            </Button>
            <Button onClick={() => handleFunction("log")} className={functionClass}>
              log
            </Button>
            <Button onClick={() => handleFunction("ln")} className={functionClass}>
              ln
            </Button>
          </div>

          {/* Scientific Functions Row 2 */}
          <div className="grid grid-cols-5 gap-2">
            <Button onClick={() => handleFunction("asin")} className={functionClass}>
              asin
            </Button>
            <Button onClick={() => handleFunction("acos")} className={functionClass}>
              acos
            </Button>
            <Button onClick={() => handleFunction("atan")} className={functionClass}>
              atan
            </Button>
            <Button onClick={() => handleFunction("sqrt")} className={functionClass}>
              √
            </Button>
            <Button onClick={() => handleOperator("^")} className={functionClass}>
              x^y
            </Button>
          </div>

          {/* Constants and Parenthesis */}
          <div className="grid grid-cols-5 gap-2">
            <Button onClick={() => handleConstant("π", "pi")} className={functionClass}>
              π
            </Button>
            <Button onClick={() => handleConstant("e", "e")} className={functionClass}>
              e
            </Button>
            <Button onClick={() => handleParenthesis("(")} className={buttonClass}>
              (
            </Button>
            <Button onClick={() => handleParenthesis(")")} className={buttonClass}>
              )
            </Button>
            <Button onClick={handleClear} className="h-14 text-lg font-semibold bg-red-500 hover:bg-red-600 text-white">
              C
            </Button>
          </div>

          {/* Number Pad */}
          <div className="grid grid-cols-4 gap-2">
            <Button onClick={() => handleNumber("7")} className={buttonClass}>
              7
            </Button>
            <Button onClick={() => handleNumber("8")} className={buttonClass}>
              8
            </Button>
            <Button onClick={() => handleNumber("9")} className={buttonClass}>
              9
            </Button>
            <Button onClick={() => handleOperator("/")} className={operatorClass}>
              ÷
            </Button>

            <Button onClick={() => handleNumber("4")} className={buttonClass}>
              4
            </Button>
            <Button onClick={() => handleNumber("5")} className={buttonClass}>
              5
            </Button>
            <Button onClick={() => handleNumber("6")} className={buttonClass}>
              6
            </Button>
            <Button onClick={() => handleOperator("*")} className={operatorClass}>
              ×
            </Button>

            <Button onClick={() => handleNumber("1")} className={buttonClass}>
              1
            </Button>
            <Button onClick={() => handleNumber("2")} className={buttonClass}>
              2
            </Button>
            <Button onClick={() => handleNumber("3")} className={buttonClass}>
              3
            </Button>
            <Button onClick={() => handleOperator("-")} className={operatorClass}>
              -
            </Button>

            <Button onClick={() => handleNumber("0")} className={buttonClass}>
              0
            </Button>
            <Button onClick={handleDecimal} className={buttonClass}>
              .
            </Button>
            <Button onClick={handleClearEntry} className={buttonClass}>
              CE
            </Button>
            <Button onClick={() => handleOperator("+")} className={operatorClass}>
              +
            </Button>
          </div>

          {/* Equals Button */}
          <Button onClick={handleEquals} className="w-full h-14 text-xl font-bold bg-green-500 hover:bg-green-600 text-white">
            =
          </Button>
        </div>
      </Card>

      {/* History */}
      {history.length > 0 && (
        <Card className="p-4 bg-slate-50">
          <h3 className="font-semibold text-lg mb-2 text-slate-900">Histórico</h3>
          <div className="space-y-1 max-h-40 overflow-y-auto">
            {history.slice().reverse().map((item, index) => (
              <div key={index} className="text-sm text-slate-700 py-1 border-b border-slate-200 last:border-0">
                {item}
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
