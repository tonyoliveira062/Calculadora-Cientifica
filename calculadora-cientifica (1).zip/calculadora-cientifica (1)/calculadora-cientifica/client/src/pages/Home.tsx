import { APP_TITLE } from "@/const";
import Calculator from "@/components/Calculator";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <div className="container py-8">
        <header className="text-center mb-8">
          <h1 className="text-5xl font-bold text-white mb-2">{APP_TITLE}</h1>
          <p className="text-slate-400 text-lg">Calculadora científica completa com suporte a funções avançadas</p>
        </header>
        <Calculator />
      </div>
    </div>
  );
}
